Mobile Preview Safe CV Templates

Fix:
- Removed outer {{#hasBody}} wrappers so mobile preview won't render blank if hasBody is missing.
- Kept section-level flags such as hasSummary, hasExperience, hasSkills, etc.
- Removed unwanted static labels / position headline lines.

Templates:
- tech-gradient
- corporate-split
- elegant-sidebar
- compact-timeline
- modular-card
